# angdashboard

Install json-server globally
npm –install –g json-server

make sure npm folder from C:\Users\<username>\AppData\Roaming\npm is in PATH of environment variables
Then move to apps directory of  mydata.json & run the command
json-server –-watch mydata.json


Run Live preview on brackets editor on index.html

